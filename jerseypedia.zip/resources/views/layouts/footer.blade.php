<footer>
    <hr>
    <div class="container">
        <div class="row">
            <div class="col text-center">
                Copyright @2021<br>
                Remake from : <a href="https://github.com/afifbasya/jerseypedia" target="_blank">https://github.com/afifbasya/jerseypedia</a>
            </div>
        </div>
    </div>
</footer>