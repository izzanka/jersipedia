
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('cart')); ?>">
        
        <i class="bi bi-cart"></i>
        Cart
        <?php if(!empty($orderdetails)): ?> 
        <span class="badge badge-success badge-pill">
            <?php echo e($orderdetails); ?></span>
        <?php endif; ?>
    </a>
</li><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/components/cart.blade.php ENDPATH**/ ?>