
<?php $__env->startSection('title'); ?>
    Cart
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row mt-4 mb-2">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Cart</li>
                </ol>
            </nav>
        </div>
    </div>
    
    <div class="row">
        <?php if(session()->has('message')): ?>
        <div class="col-12">
            <div class="alert alert-<?php echo e(session('message')['class']); ?> alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('message')['text']); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
        <?php endif; ?>
    </div>
 

    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <?php if(!empty($orderdetails)): ?>
                    <a href="<?php echo e(route('jersey')); ?>"><i class="bi bi-plus"></i> Order More</a>
                <?php endif; ?>
                <table class="table text-center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Jersey</th>
                            <th>Description</th>
                            <th>NameSet</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Total Price</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($orderdetails)): ?>
                            <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <img src="<?php echo e(url('images/jersey')); ?>/<?php echo e($orderdetail->jersey->image); ?>" class="img-fluid" width="200">
                                </td>
                                <td>
                                    <?php echo e($orderdetail->jersey->name); ?>

                                </td>
                                <td>
                                    <?php if($orderdetail->nameset): ?>
                                        Name : <?php echo e($orderdetail->name); ?> <br>
                                        Number : <?php echo e($orderdetail->number); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($orderdetail->total_order); ?>

                                </td>
                                <td>
                                    Rp. <?php echo e(number_format($orderdetail->jersey->price)); ?>

                                </td>
                                <td align="right"><strong>Rp. <?php echo e(number_format($orderdetail->total_price)); ?></strong></td>
                                <td>
                                    <a href="<?php echo e(route('cart.edit', [$orderdetail->id,"add"])); ?>"><i class="bi bi-plus-circle text-success"></i></a>
                                    <a href="<?php echo e(route('cart.edit', [$orderdetail->id,"min"])); ?>" ><i class="bi bi-dash-circle text-warning"></i></a>
                                    <a href="<?php echo e(route('cart.edit', [$orderdetail->id,"delete"])); ?>"><i class="bi bi-x-circle text-danger"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        <?php else: ?>
                        <tr>
                            <td colspan="8"><strong>Cart Empty <a href="<?php echo e(route('jersey')); ?>"> Order Now!</a> </strong> </td>
                        </tr>
                        <?php endif; ?>

                        <?php if(!empty($order)): ?>
                       
                        <?php echo e($orderdetails->links()); ?>

                          
                        <tr>
                            <td colspan="6" align="right"><strong>Total Price : </strong></td>
                            <td align="right"><strong>Rp. <?php echo e(number_format($order->total_price)); ?></strong> </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="6" align="right"><strong>Unique Code : </strong></td>
                            <td align="right"><strong><?php echo e($order->code); ?></strong> </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="7"></td>
                            <td colspan="3">
                                <a href="<?php echo e(route('cart.checkout',$order->code)); ?>" class="btn btn-success">
                                    <i class="bi bi-arrow-right-circle"></i> Check Out
                                </a>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/user/cart.blade.php ENDPATH**/ ?>