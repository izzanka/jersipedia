
<?php $__env->startSection('title'); ?>
    List Jersey
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-2">
        <div class="col">
            <nav aria-label="breadcrumb" class="mt-3">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">List Jersey</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-9">
            <h2><?php echo e($title); ?></h2>
        </div>
        <div class="col-md-3">
            <form action="<?php echo e(route('jersey')); ?>" method="GET">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="search" placeholder="Search...">
                    <div class="input-group-append">
                      <span class="input-group-text" id="basic-addon2"><i class="bi bi-search"></i></span>
                    </div>
                  </div>
            </form>
        </div>
    </div>

    <section class="jersey mb-5">
        <div class="row mt-4">
            <?php $__currentLoopData = $jerseys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jersey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-3">
                <div class="card">
                    <div class="card-body text-center">
                        <img src="<?php echo e(url('images/jersey')); ?>/<?php echo e($jersey->image); ?>" class="img-fluid" loading="lazy">
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <h5><strong><?php echo e($jersey->name); ?></strong> </h5>
                                <h5>Rp. <?php echo e(number_format($jersey->price)); ?></h5>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <a href="<?php echo e(route('jersey.detail',$jersey->id)); ?>" class="btn btn-dark btn-block"><i class="bi bi-eye"></i> Detail</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col">
                <?php echo e($jerseys->links()); ?>

            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/jersey.blade.php ENDPATH**/ ?>