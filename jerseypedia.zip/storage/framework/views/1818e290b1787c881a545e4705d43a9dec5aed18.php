
<?php $__env->startSection('title'); ?>
    About
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row mt-4 mb-2">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">About</li>
                </ol>
            </nav>
        </div>
    </div>

    

    <div class="row mb-4">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <p>
                        <i class="bi bi-person-circle"></i> Izzan Khairil Anam<br><br>
                        <i class="bi bi-instagram"></i> @izzanka<br>
                        <i class="bi bi-whatsapp"></i> 0821-1144-7470<br>
                        <i class="bi bi-github"></i> izzanka
                    </p>
                </div>
            </div>
        </div>
    </div>


   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/about.blade.php ENDPATH**/ ?>