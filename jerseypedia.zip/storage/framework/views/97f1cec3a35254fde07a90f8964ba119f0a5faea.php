<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="justify-content-center">
        
        <div class="banner">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                  <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="<?php echo e(asset('images/slider/slider2.png')); ?>" class="d-block w-100" alt="..." loading="lazy">
                  </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>

    
    <section class="league mt-4">
      <h4><strong><i class="bi bi-check2-circle"></i> Select League</strong></h4>
    <div class="row mt-4">
        <?php $__currentLoopData = $leagues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $league): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <a href="<?php echo e(route('league',$league->id)); ?>">
                <div class="card shadow">
                <div class="card-body text-center">
                    <img src="<?php echo e(asset('images/league')); ?>/<?php echo e($league->image); ?>" class="img-fluid" loading="lazy">
                </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </section>

    

    <section class="jersey mt-4 mb-4">
      <h4>
         <strong><i class="bi bi-award"></i> Best Jersey</strong>
         <a href="<?php echo e(route('jersey')); ?>" class="btn btn-dark float-right"><i class="bi bi-eye"></i> All</a>
      </h4>
      <div class="row mt-4">
         <?php $__currentLoopData = $jerseys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jersey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-3 mt-2">
            <div class="card">
               <div class="card-body text-center">
                  
                  <?php if($jersey->stock === 0): ?>
                     <i class="bi bi-exclamation-circle float-left"> <small class="text-danger"> Sold Out</small></i>
                  <?php else: ?>
                     <i class="bi bi-info-circle float-left"> <small> Sold : <i class="text-success"><?php echo e($jersey->sold); ?></i></small></i>
                  <?php endif; ?>

                  <img src="<?php echo e(url('images/jersey')); ?>/<?php echo e($jersey->image); ?>" class="img-fluid" loading="lazy">
                  <div class="row mt-2">
                     <div class="col-md-12">
                        <h5><strong><?php echo e($jersey->name); ?></strong> </h5>
                        <h5>Rp. <?php echo e(number_format($jersey->price)); ?></h5>
                     </div>
                  </div>
                  <div class="row mt-2">
                     <div class="col-md-12">
                        <a href="<?php echo e(route('jersey.detail',$jersey->id)); ?>" class="btn btn-dark btn-block"><i class="bi bi-eye"></i> Detail</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

   </section>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/home.blade.php ENDPATH**/ ?>