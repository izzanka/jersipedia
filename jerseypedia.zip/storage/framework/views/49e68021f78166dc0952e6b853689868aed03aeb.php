<table>
    <thead>
    <tr>
        <th>#</th>
        <th>User</th>
        <th>Address</th>
        <th>Phone</th>
        <th>Order Date</th>
        <th>Description</th>
        <th>Total Order</th>
        <th>Total Price</th>
        <th>Status</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($order->user->email); ?></td>
            <td><?php echo e($order->address); ?></td>
            <td><?php echo e($order->phone); ?></td>
            <td><?php echo e($order->created_at->format('d/m/Y')); ?></td>
            <td>
                <?php
                    $orderdetails = \App\OrderDetail::where('order_id',$order->id)->get();
                    $total_order = $orderdetails->sum('total_order');
                ?>
                <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($orderdetail->jersey->name); ?><b>(x<?php echo e($orderdetail->total_order); ?>)</b>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td>
               <?php echo e($total_order); ?>

            </td>
            <td><strong>Rp. <?php echo e(number_format($order->total_price)); ?></strong></td>
            <td>
                <?php if($order->status == 1): ?>
                    Payment is waiting to be confirmed
                <?php elseif($order->status == 2): ?>
                    Payment was confirmed successfully
                <?php elseif($order->status == 3): ?>
                    Payment failed to be confirmed
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/admin/order-export-excel.blade.php ENDPATH**/ ?>