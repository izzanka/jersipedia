<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('jerseys.index')); ?>">
        <i class="bi bi-archive"></i>
        Jersey
        <?php if(!empty($jerseys)): ?> 
        <span class="badge badge-primary badge-pill">
            <?php echo e($jerseys); ?></span>
        <?php endif; ?>
    </a>
</li><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/components/jerseys.blade.php ENDPATH**/ ?>