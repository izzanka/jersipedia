
<?php $__env->startSection('title'); ?>
    List Jersey
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-2">
        <div class="col">
            <nav aria-label="breadcrumb" class="mt-3">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">List Jersey</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-9">
            <h2><?php echo e($title); ?></h2><a href=""><i class="bi bi-plus"></i> Add Jersey</a>
        </div>
        <div class="col-md-3">
            <form action="<?php echo e(route('jerseys.index')); ?>" method="GET">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="search" placeholder="Search...">
                    <div class="input-group-append">
                      <span class="input-group-text" id="basic-addon2"><i class="bi bi-search"></i></span>
                    </div>
                  </div>
            </form>
        </div>
    </div>

    <section class="jersey mb-2">
        <div class="row mt-2">
            <?php $__currentLoopData = $jerseys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jersey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 mb-3">
                <div class="card">
                    <div class="card-body text-center">
                         
                        <?php if($jersey->stock === 0): ?>
                            <i class="bi bi-exclamation-circle float-left"> <small class="text-danger"> Sold Out</small></i>
                        <?php else: ?>
                            <i class="bi bi-info-circle float-left"> <small> Sold : <i class="text-success"><?php echo e($jersey->sold); ?></i></small></i>
                        <?php endif; ?>

                        <i class="bi bi-info-circle float-right"> <small> Stock : <i class="text-success"><?php echo e($jersey->stock); ?></i></small></i>
                        
                        <img src="<?php echo e(url('images/jersey')); ?>/<?php echo e($jersey->image); ?>" class="img-fluid" loading="lazy">
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <h5><strong><?php echo e($jersey->name); ?></strong> </h5>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                               <a href=""><i class="bi bi-plus-circle text-primary"></i></a>
                               <a href=""><i class="bi bi-x-circle text-danger"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col">
                <?php echo e($jerseys->links()); ?>

            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/admin/jersey.blade.php ENDPATH**/ ?>