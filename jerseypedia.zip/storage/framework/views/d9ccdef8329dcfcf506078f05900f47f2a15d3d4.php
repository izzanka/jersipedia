
<?php $__env->startSection('title'); ?>
    History
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row mt-4 mb-2">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">History</li>
                </ol>
            </nav>
        </div>
        <?php if(session()->has('message')): ?>
            <div class="col-12">
                <div class="alert alert-<?php echo e(session('message')['class']); ?> alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('message')['text']); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="row mb-4">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <p>If payment failed to be confirmed, please order again and make sure you transfer to the right account below!</p>
                    <div class="media mt-3">
                        <img class="mr-3" src="<?php echo e(url('images/payment/bca.png')); ?>" alt="Bank BRI" width="60">
                        <div class="media-body">
                            <h5 class="mt-0">BANK BCA</h5>
                            Account Number <strong>012345-678-910</strong> / <strong>Izzan Khairil Anam</strong>
                        </div>
                        <img class="mr-3" src="<?php echo e(url('images/payment/paypal.png')); ?>" alt="Bank BRI" width="60">
                        <div class="media-body">
                            <h5 class="mt-0">PAYPAL</h5>
                            Account Number <strong>012345-678-910</strong> / <strong>Izzan Khairil Anam</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table text-center table-sm">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Order Date</th>
                            <th>Unique Code</th>
                            <th>Order</th>
                            <th>Status</th>
                            <th>Total Order</th>
                            <th>Total Price</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                            <td><?php echo e($order->code); ?></td>
                            <td>
                                <?php
                                    $orderdetails = \App\OrderDetail::where('order_id',$order->id)->get();
                                    $total_order = $orderdetails->sum('total_order');
                                ?>
                                <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(url('images/jersey')); ?>/<?php echo e($orderdetail->jersey->image); ?>"
                                    class="img-fluid" width="50" loading="lazy"><br>
                                    <?php echo e($orderdetail->jersey->name); ?><b>(x<?php echo e($orderdetail->total_order); ?>)</b>
                                    <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php if($order->status == 1): ?>
                                    Payment is being confirmed
                                <?php elseif($order->status == 2): ?>
                                    Payment was confirmed successfully<br>
                                    <small>Your order will be delivered</small>
                                <?php elseif($order->status == 3): ?>
                                    Payment failed to be confirmed
                                <?php elseif($order->status == 4): ?>
                                    Order canceled
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($total_order); ?>

                            </td>
                            <td><strong>Rp. <?php echo e(number_format($order->total_price)); ?></strong></td>
                            <td>
                                <?php if($order->status == 1): ?>
                                <?php else: ?>
                                    <a href="<?php echo e(route('history.delete',$order->code)); ?>" onclick="return confirm('Are you sure?')"><i class="bi bi-trash text-danger"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>    
                            <td colspan="7"><strong>History Empty</strong></td>
                        </tr>
                        <?php endif; ?>
                
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div>
        <?php echo e($orders->links()); ?>

    </div>

   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/user/history.blade.php ENDPATH**/ ?>