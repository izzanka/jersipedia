
<?php $__env->startSection('title'); ?>
    Order Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row mt-4 mb-2">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Order Detail</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <p>Name    : <?php echo e($order->user->name); ?></p>
                    <p>Email   : <?php echo e($order->user->email); ?></p>
                    <p>Phone   : <?php echo e($order->user->phone ?? 'NULL'); ?></p>
                    <p>Address : <?php echo e($order->user->address ?? 'NULL'); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-12">
        
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Code</th>
                                    <th>Order date</th>
                                    <th>Phone</th>
                                    <th>Address</th>
                                    <th>Jersey</th>
                                    <th>Total Order</th>
                                    <th>Total Price</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                      
                                <tr>
                                    <td><?php echo e($order->code); ?></td>
                                    <td><?php echo e($order->updated_at); ?></td>
                                    <td><?php echo e($order->phone); ?></td>
                                    <td><?php echo e($order->address); ?></td>
                                    <td>
                                        <?php
                                        $orderdetails = \App\OrderDetail::where('order_id',$order->id)->get();
                                        $total_order = $orderdetails->sum('total_order');
                                        ?>
                                        <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e(url('images/jersey')); ?>/<?php echo e($orderdetail->jersey->image); ?>"
                                            class="img-fluid" width="50" loading="lazy"><br>
                                            <?php echo e($orderdetail->jersey->name); ?><b>(x<?php echo e($orderdetail->total_order); ?>)</b>
                                            <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($total_order); ?></td>
                                    <td><b class="text-danger">Rp. <?php echo e(number_format($order->total_price)); ?></b></td>
                                    <td>
                                        <?php if($order->status == 1): ?>
                                        Payment is being confirmed
                                        <?php elseif($order->status == 2): ?>
                                            Payment was confirmed successfully<br>
                                        <?php elseif($order->status == 3): ?>
                                            Payment failed to be confirmed
                                        <?php endif; ?>
                                    </td>
                                </tr>
                     
                                
                            </tbody>
                        </table>
                    </div>
        </div>
    </div>

   
   


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/admin/order-detail.blade.php ENDPATH**/ ?>