
<?php $__env->startSection('title'); ?>
    CheckOut
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-4 mb-2">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                    <li class="breadcrumb-item">Cart</li>
                    <li class="breadcrumb-item">Check Out</li>
                    <li class="breadcrumb-item active" aria-current="page">Payment</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <?php if(session()->has('message')): ?>
            <div class="alert alert-<?php echo e(session('message')['class']); ?> alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('message')['text']); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>
 
    <div class="row">
        
        <div class="col-md-4 mt-2">
            <h4><i class="bi bi-credit-card"></i> Payment Information</h4>
            <hr>
            <p class="text-danger">Please do the transfer before 24 hours, otherwise the order will be automatically failed</p>
            <p>Transfer to the account below for :<br><strong> Rp. <?php echo e(number_format($order->total_price)); ?></strong> </p>
             <div class="media mt-3">
                <img class="mr-3" src="<?php echo e(url('images/payment/bca.png')); ?>"width="60">
                <div class="media-body">
                    <h5 class="mt-0">BANK BCA</h5>
                    Account Number <strong>012345-678-910</strong> / <strong>Izzan Khairil Anam</strong>
                </div>
            </div>
            <div class="media mt-3 mb-2">
                <img class="mr-3" src="<?php echo e(url('images/payment/paypal.png')); ?>"width="60">
                <div class="media-body">
                    <h5 class="mt-0">PAYPAL</h5>
                    Account Number <strong>012345-678-910</strong> / <strong>Izzan Khairil Anam</strong>
                </div>
            </div>
        </div>

        <div class="col-md-8 mt-2">
            <h4><i class="bi bi-truck"></i> Shipping Information</h4>
            <hr>
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%">
                        <thead>
                            <tr>
                                <th>Province</th>
                                <th>City</th>
                                <th>Address</th>
                                <th>Phone</th>
                                <th>Courier</th>
                                <th>Service</th>
                                <th>Estimation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <td><?php echo e($province->province); ?></td>
                            <td><?php echo e($city->city_name); ?></td>
                            <td><?php echo e($order->address); ?></td>
                            <td><?php echo e($order->phone); ?></td>
                            <td><?php echo e(strtoupper($order->courier)); ?></td>
                            <td><?php echo e($order->service); ?></td>
                            <td><?php echo e($order->estimation); ?></td>
                        </tbody>
                    </table>
                </div>
                <form action="<?php echo e(route('cart.checkout',$order->code)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-block btn-outline-success mt-2" type="submit" onclick="return confirm('Are you sure?')">Checkout Order</button>
                </form>
                <form action="<?php echo e(route('checkout.cancel',$order->code)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-block btn-outline-danger mt-2" type="submit" onclick="return confirm('Are you sure?')">Cancel Order</button>
                </form>
                
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/user/payment.blade.php ENDPATH**/ ?>