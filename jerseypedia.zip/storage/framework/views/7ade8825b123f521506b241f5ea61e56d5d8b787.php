<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('order')); ?>">
        
        <i class="bi bi-truck"></i>
        Order
        <?php if(!empty($orders)): ?> 
        <span class="badge badge-success badge-pill">
            <?php echo e($orders); ?></span>
        <?php endif; ?>
    </a>
</li><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/components/orders.blade.php ENDPATH**/ ?>