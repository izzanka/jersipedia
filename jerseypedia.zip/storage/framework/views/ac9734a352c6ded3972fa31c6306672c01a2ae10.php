<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('history')); ?>">
        
        <i class="bi bi-clock-history"></i>
        History
        <?php if(!empty($orders)): ?> 
        <span class="badge badge-primary badge-pill">
            <?php echo e($orders); ?></span>
        <?php endif; ?>
    </a>
</li><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/components/history.blade.php ENDPATH**/ ?>