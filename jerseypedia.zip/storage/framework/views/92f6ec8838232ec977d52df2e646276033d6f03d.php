
<?php $__env->startSection('title'); ?>
    Jersey Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row mt-4 mb-2">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-dark">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('jersey')); ?>" class="text-dark">List Jersey</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Jersey Detail</li>
                </ol>
            </nav>
        </div>

        <?php if(session()->has('message')): ?>
        <div class="col-12">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo session()->get('message'); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
        <?php endif; ?>
        
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card jersey-img">
                <div class="card-body">
                    <img src="<?php echo e(url('images/jersey')); ?>/<?php echo e($jersey->image); ?>" class="img-fluid" loading="lazy">
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <h2>
                <strong><?php echo e($jersey->name); ?></strong>
            </h2>
            <h4>
                <b>Rp. <?php echo e(number_format($jersey->price)); ?></b>
                <?php if($jersey->stock === 0): ?>
                <span class="badge badge-danger ml-2"><i class="bi bi-x"></i>Not Available</span>
                <?php else: ?>
                <span class="badge badge-success ml-2"><i class="bi bi-check"></i>Available</span>
                <?php endif; ?>
            </h4>

            <div class="row">
                <div class="col">
                    <form action="<?php echo e(route('insert.cart', $jersey->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <table class="table" style="border-top : hidden">
                        <tr>
                            <td>Stock</td>
                            <td>:</td>
                            <?php if($jersey->stock === 0): ?>
                            <td class="text-danger">Sold Out</td>
                            <?php else: ?>
                            <td><?php echo e($jersey->stock); ?></td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <td>Description</td>
                            <td>:</td>
                            <td><?php echo e($jersey->description); ?></td>
                        </tr>
                        <tr>
                            <td>League</td>
                            <td>:</td>
                            <td>
                                <img src="<?php echo e(url('images/league')); ?>/<?php echo e($jersey->league->image); ?>" class="img-fluid mr-2"
                                    width="50">
                                <a href="<?php echo e(route('league',$jersey->league->id)); ?>"><?php echo e($jersey->league->name); ?></a>
                            </td>
                        </tr>
                        <tr>
                            <td>Weight</td>
                            <td>:</td>
                            <td><?php echo e($jersey->weight); ?> kg</td>
                        </tr>
                        <tr>
                            <td colspan="3">NameSet <small>(fill if you want add nameset)</small></td>
                        </tr>

                        <tr>
                            <td>NameSet Price / Latter</td>
                            <td>:</td>
                            <td><b>Rp. <?php echo e(number_format($jersey->nameset_price)); ?></b></td>
                        </tr>

                        <tr>
                            <td>Name</td>
                            <td>:</td>
                            <td>
                                <input type="text" name="name"
                                    class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" placeholder="ex : izzan">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Number</td>
                            <td>:</td>
                            <td>
                                <input type="number"
                                    class="form-control <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('number')); ?>" placeholder="0" name="number">
                                <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Amount</td>
                            <td>:</td>
                            <td>
                                <input type="number" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('amount')); ?>" placeholder="0" name="amount">
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <button type="submit" class="btn btn-dark btn-block" <?php if($jersey->stock === 0): ?> disabled <?php endif; ?>><i class="bi bi-cart-plus"></i> Insert To Cart</button>
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>

        </div>
    </div>

    <section class="jersey mt-2 mb-2">
        <h4>
           <strong><i class="bi bi-award"></i> Related Jersey</strong>
        </h4>
        <div class="row mt-2">
           <?php $__currentLoopData = $jerseys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jersey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-3 mt-2">
              <div class="card">
                 <div class="card-body text-center">
                    <img src="<?php echo e(url('images/jersey')); ?>/<?php echo e($jersey->image); ?>" class="img-fluid" loading="lazy">
                    <div class="row mt-2">
                       <div class="col-md-12">
                          <h5><strong><?php echo e($jersey->name); ?></strong> </h5>
                          <h5>Rp. <?php echo e(number_format($jersey->price)); ?></h5>
                       </div>
                    </div>
                    <div class="row mt-2">
                       <div class="col-md-12">
                          <a href="<?php echo e(route('jersey.detail',$jersey->id)); ?>" class="btn btn-dark btn-block"><i class="bi bi-eye"></i> Detail</a>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
  
     </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerseypedia\resources\views/jerseydetail.blade.php ENDPATH**/ ?>